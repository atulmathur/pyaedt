import __builtin__
import __main__
import sys
import os

# CLR
import System.Diagnostics

def builtinfunction(func):
    setattr(__builtin__, func.__name__, func)
    return func


@builtinfunction
def _ipybreak(alwaysBreak=False):
	'''Triggers a breakpoint in the interactive scripting code when
	executed. This should be called by the client code whenever they wish
	to turn debugging on.

	This will be active only if the "ANSOFT_SCRIPT_DEBUG" environment 
	variable is set. This feature is useful only if you a debugger that can
	is capable of being attached to the DLR. 
	'''
	if 'ANSOFT_SCRIPT_DEBUG' in os.environ:
		val = os.environ['ANSOFT_SCRIPT_DEBUG']		
	
		# This is the test we do inside the core code when we start up
	  	# the python engines. The two need to match so that we end up
	  	# with debugging turned on on the PythonEngine side as well.
	  	if val == "1" or val == "True" or val == "true":
			alwaysBreak = True
	
	if alwaysBreak:
		System.Diagnostics.Debugger.Break()
		if System.Diagnostics.Debugger.IsAttached == False:
			System.Diagnostics.Debugger.Launch()
	

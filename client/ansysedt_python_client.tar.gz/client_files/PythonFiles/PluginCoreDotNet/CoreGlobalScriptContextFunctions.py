from Ansys.Ansoft.PluginCoreDotNet.Util import NGDesktop
import __main__
import sys

def mainfunction(func):
    setattr(__main__, func.__name__, func)
    return func

#------------------------------------------------------------
# The following methods simply forward to the NGDesktop object
#------------------------------------------------------------
@mainfunction
def AddErrorMessage(MessageString):
	'''Adds an error message to the Application message window'''
	NGDesktop.AddErrorMessage(MessageString)


@mainfunction
def AddWarningMessage(MessageString):
	'''Adds a warning message to the application message window'''
	NGDesktop.AddWarningMessage(MessageString)

@mainfunction
def AddInfoMessage(MessageString):
	'''Adds an info message to the application message window'''
	NGDesktop.AddInfoMessage(MessageString)

@mainfunction
def AddFatalMessage(MessageString):
	'''Adds a fatal message to the application message window'''
	NGDesktop.AddFatalMessage(MessageString)


@mainfunction
def LogError(ErrorMessage):
	'''Adds an error message at level 1 into the application log'''
	NGDesktop.LogError(ErrorMessage)


@mainfunction
def LogDebug(DebugMessage):
	'''Adds a debug message at level 2 into the application log'''
	NGDesktop.LogDebug(DebugMessage)



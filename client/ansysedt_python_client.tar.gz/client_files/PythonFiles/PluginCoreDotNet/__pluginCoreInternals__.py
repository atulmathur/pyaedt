"""
This module is used to load "internal" Python modules
"""
# load the builtins first as the main functions might also need to use 
# those
from CoreBuiltinScriptContextFunctions import *

# Load the main methods next
from CoreGlobalScriptContextFunctions import *

#-----------------------------------------------------------
# Special code to add the UIToolkit's path to the assembly search
# path
#-----------------------------------------------------------
import os, sys, clr, platform, string, System
import re
import traceback
import __main__
import glob

clr.AddReference("Ansys.Ansoft.PluginCoreDotNet")
from Ansys.Ansoft.PluginCoreDotNet.Util import NGDesktop

########################### major functions ####################################
def GetAWPRootStr(exeDir, relPath):
    awp_root_str = "AWP_ROOT"
    awp_root = ""
    frmwk_dir = os.path.join(exeDir, relPath)

    try:
        if System.Environment.OSVersion.Platform == System.PlatformID.Unix:     # OS: Linux
            lib_comp_sys = os.path.join(frmwk_dir, 'libComponentSystem.so')

            if os.path.exists(lib_comp_sys):
                # We seek a string of the form: "AWP_ROOT<VERSION> by first encoding
                # "AWP_ROOT" as a byte-string
                b_awp_root = awp_root_str.encode()
                with open(lib_comp_sys, 'rb') as f:
                    s = f.read()
                    found_loc = s.find(b_awp_root)
                    if found_loc != -1:
                        sep = "\x00"
                        buffer_len = 50
                        awp_root = s[found_loc:(found_loc+buffer_len)].partition(sep.encode())[0]
        else:       # OS: Windows
            cmp_file = []

            cmp_file = glob.glob(frmwk_dir + '/ComponentSystem*')
            if len(cmp_file) == 1:
                _, tail = os.path.split(cmp_file[0])
                ver = ""
                for chr in tail:
                    if chr.isdigit():
                        ver += chr

                awp_root = awp_root_str + ver
            else:
                raise Exception("AnsProductVersion not found in " + frmwk_dir)

    except Exception as e:
        __main__.LogError("Unable to set AWP_ROOT. " + traceback.format_exc())
    
    return awp_root

# Add Framework paths to the search list. Only add the
# specific OS/Platform path
relPath = "common/Framework/bin/"
if System.Environment.OSVersion.Platform == System.PlatformID.Unix:
	relPath += "Linux"
else:
	relPath += "Win"

arch = platform.architecture()[0]
if string.find(arch, '64') != -1:
	relPath += "64"
else:
	relPath += "32"

exeDir = NGDesktop.GetExeDirectory()

# finally append the path
sys.path.append(os.path.join(exeDir, relPath))

try:
    # initialize path, environment, and load Edb API
    oaDir = os.path.join(exeDir, "common/oa")
    System.Environment.SetEnvironmentVariable("ANSYS_OADIR", oaDir)
    sys.path.append(oaDir)
    sys.path.append(exeDir)
    clr.AddReference("Ansys.Ansoft.Edb.dll")
    # For Supporting AEDT Native Toolkits on Linux
    awpRoot = GetAWPRootStr(exeDir, relPath)
    if awpRoot:
        if System.Environment.GetEnvironmentVariable(awpRoot) is None:
            comDir = os.path.join(exeDir, "common")
            System.Environment.SetEnvironmentVariable(awpRoot, comDir)
except:
    pass


"""
This module is used to load Python modules internal to the Geometry3D plugin
"""

# load the builtins first as the main functions might also need to use 
# those

# imports all classes, structures, and constants that can be used in .py script;
# imports are made available for UDMExtension and UDPExtension classes;
# so there is no need to add imports inside .py scripts
from UDP import *
from UDM import *

import __builtin__

def builtinfunction(func):
    setattr(__builtin__, func.__name__, func)
    return func


@builtinfunction
def doesfunctionexist(obj, str):
   if hasattr(obj,str):
     f1 =  getattr(obj,str)
     if hasattr(f1,"__func__"):
         return True
   return False


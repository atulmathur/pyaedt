"""
This module is used to load Python modules internal to the Geometry3D plugin
"""

# load the builtins first as the main functions might also need to use 
# those

# imports all classes, structures, and constants that can be used in .py script;
# imports are made available for UDMExtension and UDPExtension classes;
# so there is no need to add imports inside .py scripts
from Ansys.Ansoft.Geometry3DPluginDotNet.UDM.API.Interfaces import*
from Ansys.Ansoft.Geometry3DPluginDotNet.UDP.API.Interfaces import*
from Ansys.Ansoft.Geometry3DPluginDotNet.UDM import *
from Ansys.Ansoft.Geometry3DPluginDotNet.UDP import *
from Ansys.Ansoft.Geometry3DPluginDotNet.UDM.API.Data import *
from Ansys.Ansoft.Geometry3DPluginDotNet.UDM.API.Interfaces.UDMConstants import UnitType, ParamPropType, ParamDataType, ParamPropFlag, PartPropertyFlags,\
 CoordinateSystemAxis, CoordinateSystemPlane, SweepDraftType, SplitWhichSideToKeep, PolylineSegmentType, MessageSeverity, BLNDFilletRadiusLaw, BLNDFilletType, BLNDChamferRangeLaw

from Ansys.Ansoft.Geometry3DPluginDotNet.UDM.API.Interfaces import IUDMBaseExtension


class IUDMExtension(IUDMBaseExtension):
    def DoesFunctionExists(self, funcName):
        return doesfunctionexist(self, funcName)


"""
This module is used to load Python modules internal to the desktop plugin
"""
import os
import traceback
import __main__
from Ansys.Ansoft.PluginCoreDotNet.Util import NGDesktop

# load the builtins first as the main functions might also need to use 
# those
from DesktopBuiltinScriptContextFunctions import *

# Load the main methods next
from DesktopGlobalScriptContextFunctions import *

# Import OO Scripting interfaces
# ANSYEDT_OO_API_INTERNAL enable the API.Internal.Test packages as well
oo_api_int = os.getenv("ANSYSEDT_OO_API_INTERNAL") is not None
oo_api = oo_api_int or NGDesktop.IsFeatureEnabled("F128700_OOScripting")

if oo_api:
    try:
        __main__.LogDebug("ANSYSEDT_OO_API_INTERNAL is set or 'Feature:F128700_OOScripting' is enabled. Importing OO API")        
        import APIImporter
        APIImporter._importAPI(oo_api_int)
    except:
        __main__.LogError("ERROR: Exception importing APIImporter:" + traceback.format_exc() )
         

from Ansys.Ansoft.DesktopPlugin.Api import Desktop
import __builtin__
import __main__
import sys
import os

# CLR
import System.Diagnostics
import APIImporter

def builtinfunction(func):
    setattr(__builtin__, func.__name__, func)
    return func


@builtinfunction
def printheader():
    '''Prints the header when the console opens up'''
    print "==============================================================="
    print Desktop.GetApplicationName() + " " + __main__.oDesktop.GetVersion()
    print __scriptingEngine__.VersionString
    print "---------------------------------------------------------------"
    print " - With Tab completion                                         "
    print " - dir()      - lists all available methods and objects        "
    print " - dir(obj)   - lists all available attributes/methods on obj  "
    print " - help(obj)  - provides available help on a method or object  "
    print " - tutorial() - provides more help on using the console        "
    print "                                                               "
    print " try executing \"dir(oDesktop)\" or dir_sig(oDesktop,\"ver\")  "
    print "==============================================================="
    print APIImporter._getAPIHeaderExtra()


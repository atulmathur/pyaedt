from Ansys.Ansoft.DesktopPlugin.Api import DesktopWrapperForIPy
from Ansys.Ansoft.CoreCOMScripting.Util import COMUtil
import __main__
import sys

def mainfunction(func):
    setattr(__main__, func.__name__, func)
    return func

# Create an instance of the desktop wrapper context object.
scriptContext = DesktopWrapperForIPy()

#------------------------------------------------------------
# COM helper methods
#------------------------------------------------------------
@mainfunction
def CreateObject(progID):
    '''Creates a COM object for the supplied progID and returns
    the IDispatch for it if found. If not found, an exception
    is thrown'''

    # The _scopeID variable is set internally by the python engine
    # on it.
    return COMUtil.CreateObject(COMUtil.PInvokeProxyAPI, __main__._scopeID, progID)

#------------------------------------------------------------
# The following methods simply forward to the context object
#------------------------------------------------------------
@mainfunction
def SetScriptingLanguageToVBScript():
    ''' Sets the scripintLanguage state to VBScript. All script
        commands supplied for RunScriptCommand are now expected to be in
        VBScript'''
    scriptContext.SetScriptingLanguageToVBScript()

@mainfunction
def SetScriptingLanguageToJavascript():
    ''' Sets the scripintLanguage state to JavaScript. All script
        commands supplied for RunScriptCommand are now expected to be in
        JavaScript'''
    scriptContext.SetScriptingLanguageToJavascript()

@mainfunction
def RunScriptCommand(CommandString, CommandArguments):
    ''' Runs the supplied text as a script (the text is expected
    to be in either VBScript or JavaScript based on whether
    SetScriptingLanguageToVBScript() or SetScriptingLanguageToJavaScript()
    is called.'''
    return scriptContext.RunScriptCommand(CommandString, CommandArguments)

@mainfunction
def RunScriptFile(CommandFile, CommandArguments):
    '''Runs the supplied file as a script. The type of the script
    (VisualBasic|JavaScript) is deduces from the extension of the
    file.'''
    return scriptContext.RunScriptFile(CommandFile, CommandArguments)

@mainfunction
def dir_sig(obj, regex=None):
    '''Lists the functions exposed by a wrapped IDispatch object which match
    the supplied regular expression. The regular expression needs to follow
    C# syntax.

    The "*" regex is special cased to mean ".*"

    This is a utility function which simply prints all results from
    obj.match(regex)
    '''
    if type(obj).__name__ != "ADispatchWrapper" and type(obj).__name__ != "ADesktopWrapper":
        print >> sys.stderr, "dir_sig can only be called on wrapped IDispatch objects"
        return

    # default to all
    if regex is None:
        regex = ".*"

    for sig in obj.match(regex):
        print sig

@mainfunction
def dir_sig_doc(obj, regex=None):
    '''Lists the functions exposed by a wrapped IDispatch object which match
    the supplied regular expression. The regular expression needs to follow
    C# syntax.

    The "*" regex is special cased to mean ".*"

    This is a utility function which simply prints all results from
    obj.matchwithdoc(regex)
    '''
    if type(obj).__name__ != "ADispatchWrapper":
        print >> sys.stderr, "dir_sig can only be called on wrapped IDispatch objects"
        return

    # default to all
    if regex is None:
        regex = ".*"

    for (doc,sig) in obj.matchwithdoc(regex):
        doclen = len(doc)
        if doclen > 0:
            print "#- " + doc
            print sig + "\n"
        else:
            print sig


@mainfunction
def onlinehelp(obj):
    '''Opens up the application's scripting guide search at the specified keyword'''
    scriptContext.SearchScriptingHelp(obj)


@mainfunction
def tutorial():
    '''Prints out a quick tutorial on getting started with the console'''
    print """

    The Command Window implements Tab completion. What this means is: if you
    type in the first few letters of a an object, oDes say, and then hit tab,
    the rest of the characters are filled in for you. This works on object names
    as well as object methods. Try hitting tab after oDe and oDesktop.Cl. If
    multiple completions are possible, hitting the Tab key repeatedly cycles
    through each of them.

    the builtin dir() method can be used to list all items (objects, functions)
    at the global level. Use that to get a feel for what is available as soon as
    the console is opened up. Once you see an item that looks interesting, say,
    oDesktop, dir(oDesktop) can be used to explore it's bound methods. In this
    case, the methods exposed by the oDesktop object.

    The help() method will list any builtin documentation for the objects in question.
    try help("AddErrorMessage") or help(dir).

    There are a few additional methods available to provide help on Ansoft COM objects like
    oDesktop.
       - dir_sig    : Lists the function signatures of all/some methods on a COM object.
                      Use help(dir_sig) for more information.
       - dir_sig_doc: Like dir_sig but additionally also lists any builtin documentation
                      available.
       - onlinehelp : onlinehelp(keyword) launchers the product's scrpting guide and initiates
                      a search and subsequently displays the first search hit found. This can be
              used to locate detailed scripting guide information on a COM method. Use
              help(onlinehelp) for more information.
    """

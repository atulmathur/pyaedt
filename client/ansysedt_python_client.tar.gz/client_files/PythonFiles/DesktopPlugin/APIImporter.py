import sys, os, clr, traceback, importlib
from types import ModuleType

clr.AddReference("Ansys.Ansoft.PluginCoreDotNet")
from Ansys.Ansoft.PluginCoreDotNet.Util import NGDesktop

#-------------------------------------------------------------------------
# Final:
#    This has to take care of backward compatibility and migration. Exploring 
#    options. Versioned API namespaces is one option
#
#    We need an indirection to load the correct API and migration filters
#     - Given thrift objects. Not sure if object migration is even needed unless 
#       fields are removed. Ideally should never happen.
#     - IDL Methods are removed, change args, etc. Also ideally should not happen
#       but we are no longer restricted to COM
#        - Deprecation warnings
#        - Eventual retirement
#
#    However, to give us flexibility, the recording could look like This
#
#    ScriptEnv.Initialize()
#
#    # This will load the approp objects, migration handlers etc into the API
#    # namespace and should allow migration. For now, can be a simple load.
#    ScriptEnv.InitAPI("2020R1")
#       
#-------------------------------------------------------------------------
# We create a dynamic module heirarchy reflecting the object namespaces
# Core, Geometry3D etc (these will typically reflect the COM tlb lists)
# etc.
# If the names can be added without any collision with any other name,
# they are also injecte into __main__ directly. Otherwise, they remain in their
# original XXX module
#
# Since oDesktop is available directly under __main__, it would seem logical to
# keep all the variaous DataObjects in the global namespace as well. Can building
# the module tree differently if needed.
#-------------------------------------------------------------------------
import __main__
_apiIsImported = False

#-------------------------------------------------------------------------
def _getAPIHeaderExtra():
    '''
    Used by printheader to add info to the Command Window
    Should be cleaned up before this becomes a non-beta feature
    '''
    global _apiIsImported

    if not _apiIsImported:
        return ''

    # Assumes a = line on top from printheader
    return r'''
OO API is enabled                                              
                                                               
Try executing                                                  
 - "dir(API)"            - to list all API modules             
 - "dir(API.Geometry3d)" - to list all classes in Geometry3d
 - "dir(API.All)"        - to list class from all API modules
===============================================================
'''.strip()
              
#-------------------------------------------------------------------------
def _createMod(modName, parentMod=None):
    '''
    Creates a new python module with the supplied name.
    If a parentModule is supplied, then an attribute is created
    in that parent pointing to the new module (as if 'modName' 
    had been imported into paremtMod)
    '''
    __main__.LogDebug("Creating Module: %s\n" % modName)
    m = ModuleType(modName)
    sys.modules[modName] = m

    # Add to parent module
    if parentMod is not None:
        __main__.LogDebug("Adding %s to parent module %s\n" % (modName, parentMod.__name__))
        setattr(parentMod, modName, m)

    return m

#---------------------------------------------------------------------------
def _postImportSetupAPIAll(classNmModNmObjDict):
    '''
    classNmModNmObjDict = {
        class_nm : {
            mod1 : class_obj,
            mod2 : class_obj2,
            ...
            }
    }

    if a class_nm appears in multiple pacakges, it is added qualified 
    with the name of each module.

    Assumption: Flat structure API.{TLB_MODULE} and only the leaf item 
                is used for the qualification.
    '''
    # inject All API items into a 'All' module
    allMod = _createMod('All', sys.modules['API'])
    for cls_nm, modInfo in classNmModNmObjDict.items():

        if len(modInfo) == 1:
            # Only one class with that name
            # inject it unqualified
            setattr(allMod, cls_nm, modInfo.values()[0])
        else:
            # qualify with name of the module
            for mod_nm,obj in modInfo.items():
                # Take the leaf portion of the Module name
                # API.Core gives us Core for instance
                tlbName = mod_nm.split('.')[-1]
                qClassNm = "%s_%s" % (tlbName, cls_nm)
                setattr(allMod, qClassNm, obj)
                __main__.LogWarning("%s exists in multiple API modules. Adding %s.%s as %s" % (cls_nm, mod_nm, cls_nm, qClassNm))    

#---------------------------------------------------------------------------
def _importModAndParents(mod):
    mod_parts = mod.split('.')
    incr_mod = None

    for part in mod_parts:
        if incr_mod is None:
            incr_mod = part
        else:
            incr_mod = "%s.%s" % (incr_mod, part)

        # Harmless to redo importing again but best to avoid It
        if incr_mod in sys.modules:
            continue
        else:
            __main__.LogDebug("Importing %s toward import of final %s\n" % (incr_mod, mod))
            exec("import %s" % incr_mod)


#---------------------------------------------------------------------------
def _importAPIFromTNS(import_internal):
    '''
     API.APIUtil.tns is generated by ebu_thriftcl.py
     It holds info about the items generated (instead of 
     using __all__ in __init__.py) and we use that to guide
     the API assembly.

     returns a dict of all the classes imported. Allows name collisions across
     pacakges. API.Geometry3D and API.Boundary for instance can have an identically 
     named class

     {
        class_nm : { mod_nm : classObj,..}
     }
    '''    
    # import API meta info
    tnsModule = importlib.import_module('API.APIUtil.tns') 
    tns = tnsModule.tns    

    classNmModNmObjDict = {}

    # Sometimes we need to exec multiple import calls if the nesting is deep
    # so maintain a set. Initializize with API
    importedSet = {"API"}

    # Assemble the API from the 'API' items
    # in tns. structs/enums/constants
    for pyTlb,modInfo in tns.items():
        
        # Only import items listed under "Public"
        if "Public" not in modInfo:
            continue

        # import the items
        module_name = modInfo.get('IPyModule', None)
        if module_name is not None:

            # Conditionally expose internal APIs
            # Controlled by ANSYEDT_OO_API_INTERNAL in dektop env
            if module_name.startswith("API.Internal") and not import_internal:
                __main__.LogDebug("Skipping import of internal %s\n" % module_name)
                continue

            try:
                _importModAndParents(module_name)
                #__main__.LogDebug("Importing %s\n" % module_name)
                #exec("import %s" % module_name)
                tlbMod = sys.modules[module_name]                

                __main__.LogDebug("Importing classes for %s\n" % module_name)
                # Each class is in its own file. So it is a Module
                # We end up with the awkwardness that the class Vec3Dbl
                # is API.Core.Vec3Dbl.Vec3Dbl
                if 'Public' in modInfo:
                    for class_nm in modInfo['Public']:                        
                        # since we put each class in it's own file (module)
                        # we import the module. This has always been a bit of pain
                        # To use the class, you then need a 
                        # from API.Core.Vec3Dbl import Vec3Dbl which imports the class from
                        # the similarly named module.
                        clsMod = importlib.import_module("%s.%s" % (module_name, class_nm))                        

                        # To help out, get the class from the module and set it in the parent module.
                        # This replaces the module by the class and we can then simply use
                        # from API.Core import Vec3Dbl
                        clsObj = getattr(clsMod, class_nm)
                        if clsObj is not None:
                            setattr(tlbMod, class_nm, clsObj)

                            # Update global dict for later injection into big list
                            if class_nm not in classNmModNmObjDict:
                                classNmModNmObjDict[class_nm] = dict()

                            classNmModNmObjDict[class_nm][module_name] = clsObj

                        else:
                            __main__.LogError("No class %s in module %s.%s " % (class_nm, module_name, class_nm))

            except:
                __main__.LogError("Exception while importing %s: %s\n" % (module_name, traceback.format_exc()))
                continue         

    # Return dict of all the classes imported    
    return classNmModNmObjDict

#---------------------------------------------------------------------------
def _importAPI(import_internal=False):
    '''
    Process the generated API and imports all of them under the API module    
    '''
    global _apiIsImported
    if _apiIsImported:
        return

    __main__.LogDebug("Begin building scripting API\n")

    # One time
    _apiIsImported = True

    # Setup paths
    # Assume EXE_DIR/PythonFiles/Scripting/Current
    sys.path.append(os.path.join(
	    NGDesktop.GetExeDirectory(),
	    "PythonFiles",
        "Scripting",
        "Current"))
        

    # import API
    import API
    import API.APIUtil

    # Make API visible in the global module
    setattr(__main__, 'API', sys.modules['API'])    
    
    # Perform the main import
    # {
    #    class_nm : { mod_nm : classObj,..}
    #  }
    classNmModNmObjDict = _importAPIFromTNS(import_internal)    

   # Import all names into the API.All module as well. 
   # Diambiguate common names as needed.
    _postImportSetupAPIAll(classNmModNmObjDict)    
    
    __main__.LogDebug("Completed building scripting API\n")


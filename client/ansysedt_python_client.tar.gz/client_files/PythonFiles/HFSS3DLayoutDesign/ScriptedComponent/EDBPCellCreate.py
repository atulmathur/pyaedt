﻿import sys, clr, os, traceback

import Ansys.Ansoft.Edb as edb
edb.Database.SetRunAsStandAlone(False)
from Ansys.Ansoft.Edb import ProductId
from Ansys.Ansoft.Edb.Definition import *
from Ansys.Ansoft.Edb.Cell import *
from Ansys.Ansoft.Edb.Utility import Value
import Ansys.Ansoft.CoreDotNet.IO as IO

clr.AddReference("Ansys.Ansoft.PluginCoreDotNet")
from Ansys.Ansoft.PluginCoreDotNet.Util import NGDesktop
sys.path.append(os.path.join(NGDesktop.GetExeDirectory(), r"PythonFiles", r"HFSS3DLayoutDesign", r"ScriptedComponent"))

from IScriptedComponent import *

#---------------------------------------------------------

def parseArguments(argsFromUI):
    ''' Utility function to handle arguments coming from UI. For now, arguments are separated by ";".
        Return a list
    '''
    if not argsFromUI:
        return []
    return argsFromUI.strip(";").split(";")

#---------------------------------------------------------

class ScriptedComp():
    def __init__(self, db, fp, comp, varStr, parentCell):
        self._db = db
        self._fp = fp
        self._comp = comp
        self._paramsDef = ScriptedComp._Callback(self._comp.GetParameters)
        self._varStr = varStr
        self._paramsDic = self._GetParameterDictionary()
        self._compInfo = ScriptedComp._Callback(self._comp.GetComponentInfo)
        self._parentCell = parentCell
        
        # Configure the footprint cell's variable server on the initial load
        if self._IsInitialLoad():
            vs = self._fp.GetVariableServer()
            self._ConfigureVariableServer(vs)        
        
    @staticmethod
    def ConvertVariationToDictionary(variation):
        tmp = [kv.split('=') for kv in variation.strip().split()]
        return {kv[0] : eval(kv[1]) for kv in tmp}        
        
    @staticmethod
    def _Callback(func, *args):
        try:
            return func(*args)
        except:
            tb = traceback.format_exc()
            AddErrorMessage(tb)
            raise
        
    def _IsInitialLoad(self):
        return not self._varStr
    
    def _GetParameterDictionary(self):
        params = {p.Name : p for p in self._paramsDef}

        varDic = ScriptedComp.ConvertVariationToDictionary(self._varStr)
        for k, v in varDic.iteritems():
            if k in params:
                if params[k].Type == PropertyTypes.MENU:
                    params[k].Value = params[k].Menu.index(v)
                else:
                    params[k].Value = v

        return params
    
    def VerifyParameters(self):
        if self._IsInitialLoad():
            return True
        
        success, msgList = ScriptedComp._Callback(self._comp.VerifyParameters, self._paramsDic)
        if success:
            return True
            
        for msg in msgList:
            AddErrorMessage(str(msg))
            
        self._fp.SetProductProperty(ProductId.Designer, 30, "VERIFYPARAMETERFAILED")
        return False        
    
    def _ConfigureVariableServer(self, vs):
        for k in self._paramsDef:
            if k.Type == PropertyTypes.MENU:
                if not vs.SetVariableValue(str(k.Name), Value(k.Value)):
                    vs.AddMenuVariable(str(k.Name), k.Value, [Value(s) for s in k.Menu], True)
            else:
                if not vs.SetVariableValue(str(k.Name), Value(k.Value)):
                    vs.AddVariable(str(k.Name), Value(k.Value), True)
            vs.SetVariableDescription(k.Name, k.Description)

    def _SetComponentInfo(self, compDef):
        # only create definitions when the variation string is empty, which should be on load
        if self._IsInitialLoad():
            ci_block = IO.DirectBuildBlock("")
            ci_block.Add("CurrentAuthor", self._compInfo.CurrentAuthor)
            ci_block.Add("Description", self._compInfo.Description)
            ci_block.Add("Manufacturer", self._compInfo.Manufacturer)
            ci_block.Add("OriginalAuthor", self._compInfo.OriginalAuthor)
            ci_block.Add("BitMap", self._compInfo.BitMap)   
            compDef.SetProductProperty(ProductId.Designer, 31, ci_block.ToString())

    def CreateDefinitions(self):
        # only create definitions when the variation string is empty, which should be on load
        if self._IsInitialLoad():
            ScriptedComp._Callback(self._comp.CreateMaterialDefinitions, self._db, self._paramsDef)
            ScriptedComp._Callback(self._comp.CreatePadstackDefinitions, self._db, self._paramsDef)

    
    def PopulateCell(self):
        # layers
        layersList = ScriptedComp._Callback(self._comp.GetLayersList, self._parentCell)
        lc = edb.Cell.LayerCollection()
        lc.AddLayers(layersList)
        fp.GetLayout().SetLayerCollection(lc)
        
        # footprint
        ScriptedComp._Callback(self._comp.CreateFootprint, self._fp, self._paramsDic, self._parentCell)
    
    def UpdateCompDef(self, defNm):
        # only update the definition on the initial load for now
        if not self._IsInitialLoad():
            return
            
        cdef = ComponentDef.FindByName(self._db, defNm)
        if cdef.IsNull():
            return # should probably raise an exception?
        
        self._SetComponentInfo(cdef)
        
        vs = cdef.GetVariableServer()
        if not vs.IsNull():
            self._ConfigureVariableServer(vs)
            
        terminals = ScriptedComp._Callback(self._comp.GetTerminalNames)
        if terminals:
            pinD = {p.GetName() : p for p in cdef.ComponentDefPins}
            pinOrder = [pinD.get(t, ComponentDefPin.Create(cdef, t)) for t in terminals]
            cdef.ReorderPins(pinOrder)        
        
        

#---------------------------------------------------------

if __name__ == "__main__":

    args = parseArguments(ScriptArgument)   
    if len(args) != 7:
       AddErrorMessage("EDBPCellCreate: Incorrect number of arguments - {0}".format(str(args)))
       sys.exit(1)

    sys.path.insert(0, args[4])
    compModule = __import__(args[5])
    variationStr = str(args[3])
    
    db = edb.Database.FindById(int(args[0]))    
    if db.IsNull():
        AddErrorMessage("EDBPCellCreate: Database.FindById failed with id {0}".format(args[0]))
        sys.exit(1)
    
    fp = edb.Cell.Cell.FindById(db, edb.Cell.CellType.FootprintCell, int(args[2]))
    if fp.IsNull():
        AddErrorMessage("EDBPCellCreate: Cell.FindById failed with id {0}".format(args[2]))
        sys.exit(1)
        
    parentCell = edb.Cell.Cell.FindById(db, edb.Cell.CellType.CircuitCell, int(args[6]))
    
    comp = ScriptedComp(db, fp, compModule.GetComponent(), variationStr, parentCell)
    if not comp.VerifyParameters():
        sys.exit(0)
    
    comp.CreateDefinitions()
    comp.PopulateCell()
    comp.UpdateCompDef(args[1])








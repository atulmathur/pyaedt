﻿from abc import *

import sys, clr, os

from System import Environment, Convert
from System.IO import File, Path
from System.Collections.Generic import List
import System

from Ansys.Ansoft.Edb.Cell import *
from Ansys.Ansoft.Edb import *
from Ansys.Ansoft.Edb.Cell.Hierarchy import *
from Ansys.Ansoft.Edb.Cell.Primitive import *
from Ansys.Ansoft.Edb.Definition import *
from Ansys.Ansoft.Edb.Geometry import PolygonData, PointData
from Ansys.Ansoft.Edb.Utility import Command, PinPair, Rlc, Transform, Value
from Ansys.Ansoft.Edb.Cell.Terminal import *

class ScriptedComponentInfo():
    def __init__(self):
        self.CurrentAuthor = ""
        self.OriginalAuthor = ""
        self.Manufacturer = ""
        self.Description = ""
        self.BitMap = ""

def enum(**enums):
    return type('Enum', (), enums)

PropertyTypes = enum(VALUE=1, TEXT=2, NUMBER=3, CHECKBOX=4, MENU=5)
class Property():
    def __init__(self, name, type, value, desc = ""):
        self.Name = name
        self.Type = type    # e.g. one of PropertyTypes.VALUE
        self.Value = value  # value type should correspond to Type selection
        self.Menu = None
        self.Description = desc
   
    def ToDouble(self):
        return Value(self.Value).ToDouble()

class MenuProperty(Property):   
    def __init__(self, name, selIndex, valueList, desc = ""):
        ''' ctor for menu property type
            selIndex sepecifies the initial selection index from valueList (string list)
        ''' 
        self.Name = name
        self.Type = PropertyTypes.MENU
        self.Value = selIndex
        self.Menu = valueList
        self.Description = desc

    def GetMenuValue(self):
        if self.Value >= len(self.Menu):
            return None
        return self.Menu[self.Value]

MessageSeverity = enum(INFO=1, WARN=2, ERR=3)
class Message():
    def __init__(self, msg, sev = MessageSeverity.ERR):
        self.Msg = msg
        self.Severity = sev

class IScriptedComponent:

    __metaclass__ = ABCMeta
    
    @abstractmethod
    def GetVersion(self):
        ''' Return version number
        '''
        raise NotImplementedError

    @abstractmethod
    def GetComponentInfo(self):
        ''' Return component information
        '''
        return ScriptedComponentInfo()

    @abstractmethod
    def GetParameters(self):
        ''' Return a dictionary of Properties that defining this component's parameters
        '''
        raise NotImplementedError

    @abstractmethod
    def VerifyParameters(self, params):
        ''' Verify the provided parameters are valid.  Return a tuple of (success, lMessage).
            If VerifyParameters returns False, component execution is aborted and messages are issued within the AEDT message manager.
        '''
        return True, []

    @abstractmethod
    def GetTerminalNames(self):
        ''' Return a list of terminal names.  This list also establishes the terminal order for the resulting component.
        '''
        raise NotImplementedError

    @abstractmethod
    def CreateMaterialDefinitions(self, db, params):
        ''' Given a parameter map, create material definitions available for this cell
        '''
        raise NotImplementedError

    @abstractmethod
    def CreatePadstackDefinitions(self, db, params):
        ''' Given a parameter dictionary, create padstack definitions available for this cell
        '''
        raise NotImplementedError

    @abstractmethod
    def GetLayersList(self, parentCell):
        ''' Return a list of layers available to the CreateFootprint method
        '''
        raise NotImplementedError

    @abstractmethod
    def CreateFootprint(self, cell, params, parentCell):
        ''' Given a parameter dictionary with instance overrides, create geometry and terminals in the provided cell.
            All passed params Values should already be evaluated to base types (e.g. number, string, or boolean)
        '''        
        raise NotImplementedError


class APITypeInfo(object):
    '''
    Holds type information relevant to IronPython
    generated thrift structs
    '''
    def __init__(self, base_name, ipy_pkg, thrift_ns, dn_ns):
        self.BaseName  = base_name 
        self.IpyModule = ipy_pkg
        self.ThriftNS  = thrift_ns
        self.DotNetNS  = dn_ns

        # derived names
        self.IpyName    = "%s.%s" %(ipy_pkg     , base_name)
        self.ThriftName = "%s.%s" %(thrift_ns   , base_name)
        self.DotNetName = "%s.%s" %(dn_ns       , base_name)


class APIException(Exception):
    """
    Base exception raised for all API issues
    """
    def __init__(self, _msg=None, _nested=None):
        '''
        Cause can be one or a list of nested exceptions
        '''        
        self.msg = _msg
        self.nested = _nested        

        # Weird to do a base init this late. However, the IronPython
        # console in CommandWindow as simply printing out the message's
        # Message and we need to set that to the str(self) to include the
        # full nesting. This does it.
        #
        # Note that __init__ is not a constructor (__new__ does that). This is 
        # an initializer. As along as we are not using what we are initializing
        # we can do it any time,
        super(APIException, self).__init__(str(self))
    
    def ToString(self):
        return str(self)

    def __str__(self):        
        return "\n".join(self.list_with_nested())

    def list_with_nested(self):
        idStr = "  "
        myMsg = idStr + type(self).__name__ + ' ' + (self.msg if self.msg is not None else '')

        retMsg = [myMsg]
        if self.nested is not None:            
            nl = self.nested if isinstance(self.nested, list) else [self.nested]            
            for e in nl:                
                # one level lower
                if hasattr(e, 'list_with_nested'):                    
                    [retMsg.append(idStr + ne) for ne in e.list_with_nested()]                    
                else:        
                    # Add an extra \n to a leaf exception.
                    retMsg.append(idStr + str(e) + "\n")
        
        return retMsg


class PositionalArgumentCountMismatch(APIException):
    """
    Raised when positional argument count does not match the 
    number of properties in a class
    """
    def __init__(self, _msg=None, _nested=None):
        '''
        Cause can be one or a list of nested exceptions
        '''
        super(PositionalArgumentCountMismatch, self).__init__(_msg, _nested)

class UnknownPropertyException(APIException):
    """
    Raised when named arguments to a class contained an unknown
    property name
    """
    def __init__(self, _msg=None, _nested=None):
        '''
        Cause can be one or a list of nested exceptions
        '''
        super(UnknownPropertyException, self).__init__(_msg, _nested)

class ArgumentTypeMismatchException(APIException):
    """
    Raised when the supplied type is differernt from the expected one
    """
    def __init__(self, _msg=None, _nested=None):
        '''
        Cause can be one or a list of nested exceptions
        '''
        super(ArgumentTypeMismatchException, self).__init__(_msg, _nested)

class ArgumentOutOfNumericalRangeException(APIException):    
    """
    Raised when the supplied value is not in a representable range for a numerical type
    """
    def __init__(self, _msg=None, _nested=None):
        '''
        Cause can be one or a list of nested exceptions
        '''
        super(ArgumentOutOfNumericalRangeException, self).__init__(_msg, _nested)

class UnknownAPIModuleException(APIException):
    """
    Raised when an unknown IronPython API module is supplied to a method 
    that expects a known one
    """
    def __init__(self, _msg=None, _nested=None):
        '''
        Cause can be one or a list of nested exceptions
        '''
        super(UnknownAPIModuleException, self).__init__(_msg, _nested)

class UnknownThriftNamespaceException(APIException):
    """
    Raised when an unknown Thift namespace is supplied to an API
    helper that expects a known thrift namespace
    """
    def __init__(self, _msg=None, _nested=None):
        '''
        Cause can be one or a list of nested exceptions
        '''
        super(UnknownThriftNamespaceException, self).__init__(_msg, _nested)    